package javafundamentals.Assignment06.music.wind;

import javafundamentals.Assignment06.music.Playable;

public class Saxophone implements Playable {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing Saxophone");
	}

}
