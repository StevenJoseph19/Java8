package javafundamentals.Assignment06.music.string;

import javafundamentals.Assignment06.music.Playable;

public class Veena implements Playable {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing Veena");
	}

}
