// Java program to show
// left padding using
// format() method
package javafundamentals;

class Assignment08 {
	public static void main(String args[])
	{
		int num = 7044;

		// Output is 3 zero's("000") + "7044",
		// in total 7 digits
		String str = String.format("%07d", num);

		System.out.println(str);
	}
}
