package junit4.rules;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

public class TimeoutRuleTest {
	
	@Rule
	public Timeout timeout = Timeout.seconds(5);

	@Test
	public void whenTimeoutThenFailTheTest() throws InterruptedException {
		TimeUnit.SECONDS.sleep(6);
	}

}
