package junit4.rules;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ErrorCollector;

public class ErrorCollectorTest {

	@Rule
	public ErrorCollector errorCollector = new ErrorCollector();

	@Test
	public void whenMultipleExceptionsThenCollectAll() {
		errorCollector.addError(new RuntimeException("Something went wrong"));
		errorCollector.addError(new RuntimeException("Something else went wrong"));
		errorCollector.addError(new RuntimeException("Other thing that went wrong"));
	}

}
