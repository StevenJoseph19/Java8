public class Philadelphia {
	public static boolean isItSunny() {
		return true;
	}
}