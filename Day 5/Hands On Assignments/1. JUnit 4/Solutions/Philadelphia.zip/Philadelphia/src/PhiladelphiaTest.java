import static org.junit.Assert.*;

import org.junit.Test;

public class PhiladelphiaTest {

	@Test
	public void testIsItSunny() {
		assertTrue(Philadelphia.isItSunny());
	}

}
