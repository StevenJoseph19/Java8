package com.mycompany.pension.setup;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.mycompany.pension.AccountRepository;
import com.mycompany.pension.setup.AccountOpeningService;
import com.mycompany.pension.setup.AccountOpeningStatus;
import com.mycompany.pension.setup.BackgroundCheckService;
import com.mycompany.pension.setup.ReferenceIdsManager;

import java.io.IOException;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.BDDMockito.given;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.when;

class AccountOpeningServiceTest {

    private AccountOpeningService underTest;
//    private BackgroundCheckService backgroundCheckService = mock(BackgroundCheckService.class);
//    private ReferenceIdsManager referenceIdsManager = mock(ReferenceIdsManager.class);
//    private AccountRepository accountRepository = mock(AccountRepository.class);

    @BeforeEach
    void setUp() {
//        underTest = new AccountOpeningService(backgroundCheckService,referenceIdsManager,accountRepository);
    	 underTest = new AccountOpeningService(null,null,null);
    }

    @Test
    public void shouldOpenAccount() throws IOException {
        final AccountOpeningStatus accountOpeningStatus = underTest.openAccount("John", "Smith", "123XYZ9", LocalDate.of(1990, 1, 1));
        assertEquals(AccountOpeningStatus.OPENED, accountOpeningStatus);

    }
}