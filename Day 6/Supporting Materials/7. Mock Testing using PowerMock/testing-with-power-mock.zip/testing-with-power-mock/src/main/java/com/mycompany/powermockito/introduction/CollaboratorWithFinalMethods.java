package com.mycompany.powermockito.introduction;

class CollaboratorWithFinalMethods {

    final String helloMethod() {
        return "Hello World!";
    }

}