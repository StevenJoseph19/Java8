
public interface CounterInterface {
    
    public void increase();
    
    public void decrease();
    
    public int getValue();
}
