
public class ClassUsesCounter {
    
    private CounterInterface counter;
    
    public ClassUsesCounter(CounterInterface c) {
        counter = c;
    }
    
    public int multiplyCounterValue(int multiplier) {
        return counter.getValue() * multiplier;
    }
    
}
