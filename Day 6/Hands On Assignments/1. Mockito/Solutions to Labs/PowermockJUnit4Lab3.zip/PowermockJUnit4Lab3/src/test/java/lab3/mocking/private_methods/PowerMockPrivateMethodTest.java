package lab3.mocking.private_methods;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(fullyQualifiedNames = "lab3.mocking.private_methods.*")
public class PowerMockPrivateMethodTest {
	@Test
	public void testClassWithPrivateMethods_printMessage_privateMethod() throws Exception {

		String message = "Hello PowerMockito";
		String expectation = "Expectation";

		ClassWithPrivateMethods mock = PowerMockito.spy(new ClassWithPrivateMethods());
		PowerMockito.doReturn(expectation).when(mock, "printMessage", message);

		String actual = mock.privateCall(message);
		Assert.assertEquals(expectation, actual);
	}
}
