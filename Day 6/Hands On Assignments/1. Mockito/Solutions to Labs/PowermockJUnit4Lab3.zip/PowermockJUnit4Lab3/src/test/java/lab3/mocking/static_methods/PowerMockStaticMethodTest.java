package lab3.mocking.static_methods;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(fullyQualifiedNames = "lab3.mocking.static_methods.*")
public class PowerMockStaticMethodTest {
	@Test
	public void testClassWithStaticMethod_printMessage_staticMethod() {

		String message = "Hello PowerMockito"; // 1
		String expectation = "Expectation"; // 2

		PowerMockito.mockStatic(ClassWithStaticMethod.class); // 3
		PowerMockito.when(ClassWithStaticMethod.printMessage(message)).thenReturn(expectation); // 4

		String actual = ClassWithStaticMethod.printMessage(message); // 5
		Assert.assertEquals(expectation, actual); // 6
	}
}
