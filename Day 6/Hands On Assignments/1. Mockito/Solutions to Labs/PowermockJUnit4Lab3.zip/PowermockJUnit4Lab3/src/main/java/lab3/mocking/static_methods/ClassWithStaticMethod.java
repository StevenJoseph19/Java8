package lab3.mocking.static_methods;

public class ClassWithStaticMethod {

	public static String printMessage(String message) {
		return message;
	}
}
