package lab3.mocking.final_methods;

public class ClassWithFinalMethods {

	public final String printMessage(String message) {
		return message;
	}

}