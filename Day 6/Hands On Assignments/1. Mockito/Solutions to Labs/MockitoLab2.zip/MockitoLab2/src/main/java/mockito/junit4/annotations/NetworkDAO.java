package mockito.junit4.annotations;

public class NetworkDAO {
	public void save(String fileName) {
		System.out.println("Saved in network location");
	}
}
