package mockito.junit4.annotations;

public class DatabaseDAO {
	public void save(String fileName) {
		System.out.println("Saved in database");
	}
}