package mockito.junit;

public interface MathService {
	long doubleLong(long num);

	long tripleLong(long num);

	long addition(long... nums);
}
