package com.mycompany.pension.investment;

public class ExternalConnectionDetails {

    public static final String INTERNAL_PROXY_URL =
            "http://123.124.124.03/delegate";
}
