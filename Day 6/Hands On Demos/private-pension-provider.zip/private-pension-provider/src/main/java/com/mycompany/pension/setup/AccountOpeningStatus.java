package com.mycompany.pension.setup;

public enum AccountOpeningStatus {
    OPENED,
    DECLINED
}
