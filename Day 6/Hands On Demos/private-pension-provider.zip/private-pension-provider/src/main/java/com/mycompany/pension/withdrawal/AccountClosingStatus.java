package com.mycompany.pension.withdrawal;

public enum AccountClosingStatus {
    CLOSING_OK,
    CLOSING_PENDING,
    CLOSING_DENIED
}
