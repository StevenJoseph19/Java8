package collections.java8;

import java.util.ArrayList;

import collections.operations.MyClass;

public class RetrieveArray {

	public static void main(String[] args) {
		ArrayList<MyClass> list = new ArrayList<>();

		list.add(new MyClass("v1", "abc"));
		list.add(new MyClass("v2", "xyz"));
		list.add(new MyClass("v3", "abc"));

		Object[] objArray = list.toArray();

		MyClass[] a1 = list.toArray((new MyClass[0]));

		MyClass[] a2 = new MyClass[3];

		MyClass[] a3 = list.toArray(a2);

		if (a2 == a3)
			System.out.println("a2 and a3 reference the same collection.");

	}

}
