package collections.simple;

public class SomeClassIMadeUp {

}
