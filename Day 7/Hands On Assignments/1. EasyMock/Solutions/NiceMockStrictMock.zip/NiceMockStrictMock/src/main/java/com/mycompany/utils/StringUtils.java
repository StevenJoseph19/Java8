package com.mycompany.utils;

public class StringUtils {

	public void print(String s) {
		System.out.println(s);
	}

	public String toUpperCase(String s) {
		return s.toUpperCase();
	}
}