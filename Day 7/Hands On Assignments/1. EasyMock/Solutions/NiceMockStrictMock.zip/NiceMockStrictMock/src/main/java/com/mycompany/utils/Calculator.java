package com.mycompany.utils;

public interface Calculator {

	int add(int x, int y);
	int multiply(int x, int y);
}