package com.testing.easymock;

public class ServiceUnavailableException extends Exception {

    private static final long serialVersionUID = 6961151537340723535L;

}