package com.mycompany.pensionready.reporting;

public interface GovernmentDataPublisher {

    void publishAccountOpeningEvent(String id);
}
