package com.mycompany.pensionready.withdrawal;

public class AccountClosingService {
    //implementation not relevant for this course module
}
