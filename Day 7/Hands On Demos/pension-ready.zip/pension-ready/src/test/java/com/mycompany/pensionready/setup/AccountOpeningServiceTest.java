package com.mycompany.pensionready.setup;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.mock;
import static org.easymock.EasyMock.niceMock;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import com.mycompany.pensionready.AccountRepository;
import com.mycompany.pensionready.reporting.GovernmentDataPublisher;

class AccountOpeningServiceTest {
	
	 static final String FIRST_NAME = "John";
	 static final String LAST_NAME = "Smith";
	 static final String TAX_ID = "123XYZ9";
	 static final LocalDate DOB = LocalDate.of(1990, 1, 1);

	private AccountOpeningService underTest;
	private BackgroundCheckService backgroundCheckService = mock(BackgroundCheckService.class);
	private BackgroundCheckService niceBackgroundCheckService = niceMock(BackgroundCheckService.class);
	private ReferenceIdsManager referenceIdsManager = mock(ReferenceIdsManager.class);
	private AccountRepository accountRepository = mock(AccountRepository.class);
	private GovernmentDataPublisher governmentDataPublisher = mock(GovernmentDataPublisher.class);

//	@BeforeEach
//	void setup() {
//		underTest = new AccountOpeningService(null, null, null);
//		underTest = new AccountOpeningService(
//				backgroundCheckService, 
//				referenceIdsManager, 
//				accountRepository);
//	}

	@Test
	void shouldDeclineAccountOpeningWhenBackgroundCheckResultsAreNull() throws IOException {
		underTest = new AccountOpeningService(
				backgroundCheckService, 
				referenceIdsManager, 
				accountRepository,
				governmentDataPublisher);
		expect(backgroundCheckService.confirm(FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB))
				.andReturn(null);
		
		replay(backgroundCheckService, 
				referenceIdsManager, 
				accountRepository,
				governmentDataPublisher);

		final AccountOpeningStatus accountOpeningStatus = underTest.openAccount(FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB);
		assertEquals(AccountOpeningStatus.DECLINED, accountOpeningStatus);
		verify(backgroundCheckService, 
			   referenceIdsManager, 
			   accountRepository,
			   governmentDataPublisher);
	}
	
	@Test
	void shouldDeclineAccountOpeningWhenBackgroundCheckResultsAreNull2() throws IOException {
		underTest = new AccountOpeningService(
				niceBackgroundCheckService, 
				referenceIdsManager, 
				accountRepository,
				governmentDataPublisher);
//		expect(backgroundCheckService.confirm(FIRST_NAME, 
//				LAST_NAME, 
//				TAX_ID,
//				DOB))
//				.andReturn(null);
		
		replay(niceBackgroundCheckService, 
				referenceIdsManager, 
				accountRepository,
				governmentDataPublisher);

		final AccountOpeningStatus accountOpeningStatus = underTest.openAccount(FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB);
		assertEquals(AccountOpeningStatus.DECLINED, accountOpeningStatus);
	}

}
