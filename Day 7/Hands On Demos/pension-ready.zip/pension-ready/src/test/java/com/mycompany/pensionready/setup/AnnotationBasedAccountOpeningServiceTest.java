package com.mycompany.pensionready.setup;

import static com.mycompany.pensionready.setup.AccountOpeningServiceTest.*;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.mock;
import static org.easymock.EasyMock.niceMock;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.anyString;
import static org.easymock.EasyMock.eq;
import static org.easymock.EasyMock.same;
import static org.easymock.EasyMock.expectLastCall;
import static org.easymock.EasyMock.verify;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import javax.management.RuntimeErrorException;

import org.easymock.EasyMockExtension;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.mycompany.pensionready.AccountRepository;
import com.mycompany.pensionready.reporting.GovernmentDataPublisher;

@ExtendWith(EasyMockExtension.class)
class AnnotationBasedAccountOpeningServiceTest {

	private static final BackgroundCheckResults ACCEPTABLE_BACKGROUND_CHECK_RESULTS = new BackgroundCheckResults("an acceptable risk profile",5000000);

	private static final String ACCOUNT_ID = "account id";
	
	@TestSubject  
	AccountOpeningService underTest = new AccountOpeningService() ;
	
	@Mock
	private BackgroundCheckService backgroundCheckService;
	
	@Mock
	private ReferenceIdsManager referenceIdsManager;
	@Mock
	private AccountRepository accountRepository;
	
	@Mock
	private GovernmentDataPublisher governmentDataPublisher;

	@Test
	public void shouldDeclineIfBackgroundCheckResultsRiskProfileUnacceptable() throws IOException {
		
		expect(backgroundCheckService.confirm(
				FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB))
				.andReturn(new BackgroundCheckResults(AccountOpeningService.UNACCEPTABLE_RISK_PROFILE, 0));
		
		replay(backgroundCheckService, 
				referenceIdsManager, 
				accountRepository);
		
		final AccountOpeningStatus accountOpeningStatus = underTest.openAccount(
				FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB);
		
		assertEquals(AccountOpeningStatus.DECLINED, accountOpeningStatus);
	}
	
	@Test
	public void shouldOpenAccount() throws IOException {
		
		expect(backgroundCheckService.confirm(
				FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB))
				.andReturn(ACCEPTABLE_BACKGROUND_CHECK_RESULTS);
		
		expect(referenceIdsManager.obtainId(
				eq(FIRST_NAME),
				anyString(),
				eq(LAST_NAME), 
				eq(TAX_ID),
				eq(DOB)))
				.andReturn(ACCOUNT_ID);
		
		expect(accountRepository.save(
				eq(ACCOUNT_ID),
				eq(FIRST_NAME), 
				eq(LAST_NAME), 
				eq(TAX_ID),
				eq(DOB),
				same(ACCEPTABLE_BACKGROUND_CHECK_RESULTS)))
				.andReturn(true);
	
		governmentDataPublisher.publishAccountOpeningEvent(ACCOUNT_ID);
		
		expectLastCall().anyTimes();
		
		replay(backgroundCheckService, 
				referenceIdsManager, 
				accountRepository,
				governmentDataPublisher);
		
		final AccountOpeningStatus accountOpeningStatus = underTest.openAccount(
				FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB);
		
		assertEquals(AccountOpeningStatus.OPENED, accountOpeningStatus);
		verify(backgroundCheckService, 
				referenceIdsManager, 
				accountRepository,
				governmentDataPublisher);
	}
	
	@Test
	public void shouldThrowIfBackgroundCheckServiceThrows() throws IOException {
		
		final String thrownMsg = "a custom message that we can assert on later.";
		
		expect(backgroundCheckService.confirm(
				FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB))
				.andThrow(new IOException(thrownMsg));
		
		replay(backgroundCheckService);
		
		final IOException thrown  = assertThrows(IOException.class, () -> underTest.openAccount(
				FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB));
		
		assertEquals(thrownMsg, thrown.getMessage());
	}
	
	@Test
	public void shouldThrowIfReferenceIdManagerThrows() throws IOException {
		
		expect(backgroundCheckService.confirm(
				FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB))
				.andReturn(ACCEPTABLE_BACKGROUND_CHECK_RESULTS);
		final String expectedThrownMsg = "a message for our runtime exception.";
		
		expect(referenceIdsManager.obtainId(
				eq(FIRST_NAME),
				anyString(),
				eq(LAST_NAME), 
				eq(TAX_ID),
				eq(DOB)))
				.andThrow(new RuntimeException(expectedThrownMsg));
		
		
		
		replay(backgroundCheckService, 
				referenceIdsManager);
		

		final RuntimeException thrown  = assertThrows(RuntimeException.class, () -> underTest.openAccount(
				FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB));
		
		assertEquals(expectedThrownMsg, thrown.getMessage());
	}
	
	
	@Test
	public void shouldThrowIfGovernmnetDataPublisherThrows() throws IOException {
		
		expect(backgroundCheckService.confirm(
				FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB))
				.andReturn(ACCEPTABLE_BACKGROUND_CHECK_RESULTS);
		
		expect(referenceIdsManager.obtainId(
				eq(FIRST_NAME),
				anyString(),
				eq(LAST_NAME), 
				eq(TAX_ID),
				eq(DOB)))
				.andReturn(ACCOUNT_ID);
		
		expect(accountRepository.save(
				eq(ACCOUNT_ID),
				eq(FIRST_NAME), 
				eq(LAST_NAME), 
				eq(TAX_ID),
				eq(DOB),
				same(ACCEPTABLE_BACKGROUND_CHECK_RESULTS)))
				.andReturn(true);
	
		governmentDataPublisher.publishAccountOpeningEvent(ACCOUNT_ID);
		
		final String govtDataExpectedThrownMsg = "government data exception.";
		
		expectLastCall().andThrow(new RuntimeException(govtDataExpectedThrownMsg));
		
		replay(backgroundCheckService, 
				referenceIdsManager, 
				accountRepository,
				governmentDataPublisher);
		
		final RuntimeException actualThrown  = assertThrows(RuntimeException.class, () -> underTest.openAccount(
				FIRST_NAME, 
				LAST_NAME, 
				TAX_ID,
				DOB));
		
		assertEquals(govtDataExpectedThrownMsg, actualThrown.getMessage());
	}

}
